﻿using lab13v1.Data;
using lab13v1.Models;
using lab13v1.Requests;
using lab13v1.Responses;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace lab13v1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CustomersCustomController : ControllerBase
    {
        private readonly CustomerContext _context;
        public CustomersCustomController(CustomerContext context)
        {
            _context = context;
        }

        [HttpGet]
        public  List<CustomerResponseV1> GetAll()
        {
            List<Customer> customers= _context.Customers.Where(x => x.IsActive).ToList();

            //Convertir de Customer a CustomerResponseV1
            //a. Foreach
            //b. expresion Lambda
            //c. librerías (Automapper)

            List<CustomerResponseV1> response = customers.Select(x => new CustomerResponseV1
            {
                DocumentNumber = x.DocumentNumber,
                FirstName = x.FirstName,
                LastName = x.LastName
            }).ToList();

            return response;
        }

        [HttpGet]
        public List<CustomerResponseV1> GetByName(string firstname)
        {
            List<Customer> customers = _context.Customers.Where(x => x.IsActive && 
            x.FirstName.Contains(firstname)
            ).ToList();
           
            List<CustomerResponseV1> response = customers.Select(x => new CustomerResponseV1
            {
                DocumentNumber = x.DocumentNumber,
                FirstName = x.FirstName,
                LastName = x.LastName
            }).ToList();

            return response;
        }

        [HttpGet]
        public List<CustomerResponseV1> GetByLastName(string lastName)
        {
            List<Customer> customers = _context.Customers.Where(x => x.IsActive &&
            x.LastName.Contains(lastName)
            ).ToList();

            List<CustomerResponseV1> response = customers.Select(x => new CustomerResponseV1
            {
                DocumentNumber = x.DocumentNumber,
                FirstName = x.FirstName,
                LastName = x.LastName
            }).ToList();

            return response;
        }

        [HttpPost]
        public void Insert(CustomerRequestV1 request)
        {         
            //Convertir de request a model
            var model = new Customer
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                DocumentNumber = request.DocumentNumber,
                IsActive = true // Por defecto, al crear un cliente, está activo
            };

            _context.Customers.Add(model);
            _context.SaveChanges();            
        }

        [HttpPut]
        public void Update(CustomerRequestV2 request)
        {

          var model= _context.Customers.
                FirstOrDefault(x => x.CustomerId == request.CustomerId && x.IsActive);
           
            model.FirstName=request.FirstName;
            model.LastName = request.LastName;
            model.DocumentNumber = request.DocumentNumber;

            _context.SaveChanges();
        }
    }
}
