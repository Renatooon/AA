﻿namespace lab13v1.Responses
{
    public class CustomerResponseV1
    {

        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string DocumentNumber { get; set; } = string.Empty;
    }
}
