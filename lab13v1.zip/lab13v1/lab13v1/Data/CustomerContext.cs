﻿using lab13v1.Models;
using Microsoft.EntityFrameworkCore;

namespace lab13v1.Data
{
    public class CustomerContext : DbContext
    {
        public CustomerContext(DbContextOptions<CustomerContext> options)
            : base(options)
        {
        }

        public DbSet<Customer> Customers => Set<Customer>();
        public DbSet<Invoice> Invoices => Set<Invoice>();
        public DbSet<Product> Products => Set<Product>();
        public DbSet<Detail> Details => Set<Detail>();
    }
}
