﻿namespace lab13v1.Requests
{
    public class CustomerRequestV1
    {
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string DocumentNumber { get; set; } = string.Empty;      
    }
}
